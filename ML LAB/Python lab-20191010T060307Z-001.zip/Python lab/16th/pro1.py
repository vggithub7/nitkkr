#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 25 20:51:11 2018

@author: sunbeam
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# data cleaning

# read the datset

# remove NA values

# categorical to continous

# add new columns

# remove columns

# split the data into train and test

# perform the logic

# consume the result

# visualize the result